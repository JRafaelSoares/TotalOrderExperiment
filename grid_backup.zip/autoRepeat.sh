python3 autoExtend.py --nr_extensions 10 --disable_at_forbidden_hours true --user rasoares
